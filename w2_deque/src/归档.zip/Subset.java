
public class Subset {
	public static void main(String[] args) {
		
	}
}
